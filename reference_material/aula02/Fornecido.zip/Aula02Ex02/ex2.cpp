#include <iostream>
using namespace std;

void calculaAtividade (double horasDiarias[], double valoresPorHora[],
                       int horasNecessarias, double* custo, int &duracao, int quantidade) {
    //Implemente aqui!
}

//Utilize o main para testar a funcao
//NAO ESQUECER DE APAGAR ANTES DE ENVIAR AO JUDGE!!!
int main() {
    cout << "Aula02ex01" << endl;
    return 0;
}
