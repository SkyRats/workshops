#include <iostream>
#include <cmath>

using namespace std;

bool ehProximo(double a, double b) {
    return abs(a - b) < 0.001;
}

double* encontrarPessoa(double valoresPorHora[], double horasDiarias[],
                        int quantidade, double valorPorHora, double horaDiaria) {
    //Implemente aqui!
}

//Utilize o main para testar a funcao
//NAO ESQUECER DE APAGAR ANTES DE ENVIAR AO JUDGE!!!
int main() {
    cout << "Aula02ex01" << endl;
    return 0;
}
