#include "Aluno.h"

void Aluno::setNome(string nome) {
	this->nome = nome;
}

string Aluno::getNome() {
	return nome;
}




