#ifndef AVALIACAO_H
#define AVALIACAO_H

class Avaliacao {
private:
	double p1, p2, p3;
public:
	void setNotas(double p1, double p2, double p3);
	double getMedia();
};

#endif // AVALIACAO_H
