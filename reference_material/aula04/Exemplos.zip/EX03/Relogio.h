class Relogio {
private:
	int hora = 0;
	int minuto = 0;
public:
	void inicializar (int hora, int minuto);
	int getHora();
	int getMinuto();
	void imprimir();
};
