#include <iostream>

using namespace std;

int main() {
    // Implemente os testes necessarios

    return 0;
}
