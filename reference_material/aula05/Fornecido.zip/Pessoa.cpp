#include "Pessoa.h"

string Pessoa::getNome() {
    return this->nome;
}

int Pessoa::getHorasDiarias() {
    return this->horasDiarias;
}

void Pessoa::imprimir() {
    cout << this->nome << ": " << this->horasDiarias << " hora(s) por dia" << endl;
}
