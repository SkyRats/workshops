#include <iostream>

using namespace std;

int main() {
    // Implementar testes
    return 0;
}
