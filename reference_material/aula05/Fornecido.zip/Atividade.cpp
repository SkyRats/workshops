#include "Atividade.h"

string Atividade::getNome() {
    return this->nome;
}

int Atividade::getHorasNecessarias() {
    return this->horasNecessarias;
}

int Atividade::getQuantidade() {
    return this->quantidade;
}

int Atividade::getDuracao() {
    double totalHoras = 0;

    if (quantidade == 0)
        return -1;

    for (int i = 0; i < quantidade; i++)
        totalHoras += pessoas[i]->getHorasDiarias();
    return ceil(horasNecessarias/totalHoras);
}

bool Atividade::adicionar(Pessoa* p) {
    if (quantidade >= NUMERO_MAXIMO_VALORES)
        return false;

    pessoas[quantidade] = p;
    quantidade++;
    return true;
}

void Atividade::imprimir() {
    cout << this->nome << " - " << this->getDuracao() << " dia(s) estimado(s)" << endl;
    for (int i = 0; i < quantidade; i++)
        pessoas[i]->imprimir();
}
