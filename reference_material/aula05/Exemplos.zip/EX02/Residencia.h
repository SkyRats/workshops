#ifndef RESIDENCIA_H
#define RESIDENCIA_H

class Residencia {
public:
  Residencia();
};

#endif // RESIDENCIA_H
