#include "Residencia.h"

#include <iostream>

using namespace std;

Residencia::Residencia() {
}
