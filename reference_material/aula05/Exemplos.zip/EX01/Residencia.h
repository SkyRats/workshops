#ifndef RESIDENCIA_H
#define RESIDENCIA_H

class Residencia {
};

#endif // RESIDENCIA_H
