#include <iostream>
using namespace std;

int main() {
	// Exemplos com cin
	cout << "Digite um a" << endl;
	int a = 0;
	cin >> a;

	cout << "O a digitado foi " << a << endl;

	// Exemplos com cout
	int i = 5;
	cout << "Ola" << endl;
	cout << i;

	cout << endl;

	int x = 5, y = 6;
	cout << "x vale " << x << " e y vale " << y << endl;

	return 0;
}
