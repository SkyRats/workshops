#include <iostream>
#include <string>
using namespace std;

int main() {
	string nome = "Jose";
	nome = "Pedro";
	char inicial = nome[0];
	cout << inicial << endl;
	return 0;
}
